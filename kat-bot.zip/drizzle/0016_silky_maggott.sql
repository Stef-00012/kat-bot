ALTER TABLE "social_credits_thresholds" RENAME COLUMN "threshold_type" TO "type";--> statement-breakpoint
ALTER TABLE "social_credits_thresholds" ALTER COLUMN "type" SET DATA TYPE type;