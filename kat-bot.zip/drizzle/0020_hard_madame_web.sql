DROP TABLE "social_credits";--> statement-breakpoint
DROP TABLE "social_credits_thresholds";