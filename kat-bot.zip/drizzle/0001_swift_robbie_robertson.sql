ALTER TABLE "automod_rules" DROP CONSTRAINT "automod_rules_guild_id_guilds_id_fk";
