# Kat Bot
Developed by Linker-123

Currently featuring an advanced AutoMod framework, allowing for easy addition of new AutoMod filters and rules

Feel free to contribute to the code!

### Available commands:
- /help
- /ratelimit
- /threshold