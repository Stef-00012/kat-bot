import { ChatInputCommandInteraction, EmbedBuilder } from "discord.js";
import { db } from "../../db";
import { and, eq } from "drizzle-orm";
import { socialCredits } from "../../schema";

export const execute = async (inter: ChatInputCommandInteraction) => {
  if (!inter.guild) return;

  await inter.deferReply()

  const user = inter.options.getUser("member") || inter.user

    const existingUser = await db.query.socialCredits.findFirst({
        where: and(
          eq(socialCredits.guildId, inter.guildId!),
          eq(socialCredits.userId, user.id)
        ),
      });

    if (!existingUser) await db.insert(socialCredits).values({
      guildId: inter.guild.id,
      userId: user.id
    })

    const embed = new EmbedBuilder()
      .setTitle(`Social credits`)
      .setDescription(`${user.username} has ${existingUser?.credits || 500} social credits`)

    await inter.editReply({
      embeds: [embed]
    })
}