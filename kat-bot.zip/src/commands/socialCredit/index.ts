import { ChatInputCommandInteraction, SlashCommandBuilder } from "discord.js";
import fs from "fs";
import path from "path";

export const command = new SlashCommandBuilder()
    .setName("credit")
    .setDescription("Social credit related commands")
    .addSubcommand((subcommand) =>
      subcommand
          .setName("add")
          .setDescription("Adds social credit to a user")
          .addUserOption((option) =>
            option
                .setName("member")
                .setDescription("The user to add the social credit to")
                .setRequired(true)
            )
          .addIntegerOption(option =>
            option
                .setName("amount")
                .setDescription("The amount of social credits to add")
                .setRequired(true)
            )
          .addStringOption(option =>
            option
                .setName("reason")
                .setDescription("The reason for the social credit change")
                .setRequired(false)
            )
      )
    .addSubcommand(subcommand =>
        subcommand
            .setName("remove")
            .setDescription("Removes social credit to a user")
            .addUserOption(option => 
                option
                    .setName("member")
                    .setDescription("The user to add the social credit to")
                    .setRequired(true)
                )
            .addIntegerOption(option => 
                option
                    .setName("amount")
                    .setDescription("The amount of social credits to remove")
                    .setRequired(true)
                )
            .addStringOption(option => 
                option
                    .setName("reason")
                    .setDescription("The reason for the social credit change")
                    .setRequired(false)
                )

      )
    .addSubcommand(subcommand =>
        subcommand
            .setName("view")
            .setDescription("View your social credit")
            .addUserOption(option => 
                option
                    .setName("member")
                    .setDescription("The user you want to see the credit of (moderator only)")
                    .setRequired(false)
            )
      )
    .addSubcommandGroup(subcommandGroup =>
      subcommandGroup
            .setName("treshold")
            .setDescription("Manage the thresholds for social credit related roles")
            .addSubcommand(subcommand =>
                subcommand
                    .setName("add")
                    .setDescription("Add a treshold")
                    .addStringOption(option => 
                        option
                            .setName("type")
                            .setDescription("the type of treshold")
                            .setChoices([
                                {
                                    name: "Good",
                                    value: "good"
                                },
                                {
                                    name: "Bad",
                                    value: "bad"
                                }
                            ])
                            .setRequired(true)
                    )
                    .addIntegerOption(option => 
                        option
                            .setName("name")
                            .setDescription("The threshold name")
                            .setRequired(true)
                    )
                    .addRoleOption(option => 
                        option
                            .setName("role")
                            .setDescription("the role to add")
                            .setRequired(true)
                        )
            )
            .addSubcommand(subcommand =>
                subcommand
                .setName("remove")
                .setDescription("Remove a treshold")
                .addRoleOption(option => 
                    option
                        .setName("threshold")
                        .setDescription("The threshold to remove")
                        .setRequired(true)
                )
            )
            .addSubcommand(subcommand =>
                subcommand
                .setName("view")
                .setDescription("View a treshold data")
                .addRoleOption(option =>
                    option
                        .setName("role")
                        .setDescription("The role to view the threshold of")
                        .setRequired(true)
                )
            )
    )

export async function execute(inter: ChatInputCommandInteraction) {
    const selectedSubcommandGroup = inter.options.getSubcommandGroup()
    const selectedSubcommand = inter.options.getSubcommand()

    let filePath;

    if (selectedSubcommandGroup) filePath = path.join(__dirname, selectedSubcommandGroup, `${selectedSubcommand}.ts`)
    else filePath = path.join(__dirname, `${selectedSubcommand}.ts`)

    if (!fs.existsSync(filePath)) return; // idk se mandare un qualche msg qua, bo idk

    const { execute } = await import(filePath)

    if (!execute) return; // idk se mandare un qualche msg qua

    await execute(inter)
}
