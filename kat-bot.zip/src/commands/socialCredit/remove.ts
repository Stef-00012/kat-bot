import { ChatInputCommandInteraction, EmbedBuilder } from "discord.js";
import { db } from "../../db";
import { and, eq } from "drizzle-orm";
import { socialCredits } from "../../schema";

export const execute = async (inter: ChatInputCommandInteraction) => {
    if (!inter.guild) return;

    await inter.deferReply()
    
    const user = inter.options.getUser("member")
    const amount = inter.options.getInteger("amount", true)
    const reason = inter.options.getString("reason")

    if (!user) return inter.editReply({
        content: "I could not find this user."
    })

    let existingUser = await db.query.socialCredits.findFirst({
        where: and(
          eq(socialCredits.guildId, inter.guildId!),
          eq(socialCredits.userId, user.id)
        ),
      });

    if (!existingUser) {
        existingUser = {
            guildId: inter.guild.id,
            userId: user.id,
            credits: 500 - amount
        }

        await db.insert(socialCredits).values({
            ...existingUser
        })
    } else {
        existingUser.credits -= amount
        
        await db
            .update(socialCredits)
            .set({
                ...existingUser
            })
            .where(
                and(
                    eq(socialCredits.guildId, inter.guildId!),
                    eq(socialCredits.userId, user.id)
                )
            )
    }



    const embed = new EmbedBuilder()
      .setTitle(`Social credits`)
      .setDescription(`${user.username} has lost ${amount} social credits. Now they have ${existingUser.credits} social credits.${reason ? `\nReason: ${reason}` : ""}`)

    await inter.editReply({
      embeds: [embed]
    })
}